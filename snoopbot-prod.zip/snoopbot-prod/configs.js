module.exports = {
	APP_STATE_FILE: "appstate.json",
    APP_PERMISSION_FILE: "permissions.json",
    APP_THREAD_WHITELIST_FILE: "thread-whitelist.json",
    APP_SETTINGS_LIST_FILE: "settings-list.json",
    APP_PINNED_MESSAGES_FILE: "pinned-messages.json"
};